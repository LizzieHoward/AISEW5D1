# Make `app` a package so tests can import `app.calculator`
